# d1snake

A simple Snake game written in Python using Pygame.

## Installation

```bash
pip install d1snake
